package com.androidui.projecttwo.models;

import java.util.ArrayList;

public class Event {

    long id;

    private String name;

    private String date;

    // full event constructor
    public Event(long id, String name, String date) {
        this.id = id;
        this.name = name;
        this.date = date;
    }

    // new event constructor, id is created later
    public Event(String name, String date) {
        this.name = name;
        this.date = date;
    }

    // setters
    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    // getters
    public long getId() { return id; }

    public String getName() { return name; }

    public String getDate() { return date; }

}
