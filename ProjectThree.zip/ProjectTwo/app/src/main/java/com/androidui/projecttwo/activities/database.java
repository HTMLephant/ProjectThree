package com.androidui.projecttwo.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.androidui.projecttwo.R;
import com.androidui.projecttwo.adapters.EventAdapter;
import com.androidui.projecttwo.db.EventDBHelper;
import com.androidui.projecttwo.models.Event;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class database extends AppCompatActivity {
    Button addButton;
    ArrayList<Event> events;
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        addButton = findViewById(R.id.addButton);

        events = new ArrayList<>();

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executorService.execute(() -> {
            EventDBHelper.getInstance(database.this).getAllEvents(events);

            handler.post(() -> Toast.makeText(database.this, R.string.retrivedEvent, Toast.LENGTH_SHORT));
        });

        adapter = new EventAdapter(this, R.layout.event_list_item, events);
        GridView gridView = findViewById(R.id.dataGrid);

        gridView.setAdapter(adapter);

        // Existing event is clicked
        gridView.setOnItemClickListener((parent,view,position,id) -> {
            Event ev = adapter.getItem(position);
            if(ev != null){
                updateOrDelete(ev);
            }
        });

        // Add button pressed
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(database.this, addEvent.class);
                startActivity(intent);
            }
        });

    }
    // Jump to update event activity
    private void updateEvent(Event event) {
        Intent intent = new Intent(database.this,updateEvent.class);
        startActivity(intent);
    }
    private void updateOrDelete(Event event) {
        EventDBHelper db = EventDBHelper.getInstance(this);
        String[] Options = {"Update","Delete"};
        final String[] selected = new String[1];

        // Popup dialog box
        AlertDialog.Builder builder = new AlertDialog.Builder(database.this);
        builder.setTitle("Options for " + event.getName().toString());
        builder.setSingleChoiceItems(Options, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                selected[0] = Options[i];
            }
        });
        builder.setPositiveButton(R.string.okay_label, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                // Update event
                if (selected[0] == "Update") {
                    dialog.dismiss();
                    updateEvent(event);
                    adapter.notifyDataSetChanged();

                }
                // Delete event
                else {
                    db.delete(event);
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                }
            }
        });
        builder.setNegativeButton(R.string.cancel_label, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                dialog.cancel();
            }
        });
        builder.show();

    }

}


