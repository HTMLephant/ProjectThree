package com.androidui.projecttwo.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

import com.androidui.projecttwo.models.Event;

import java.util.ArrayList;

public class EventDBHelper extends SQLiteOpenHelper {

    // create a simple singleton that allows us to access the helper in different activities
    // without always having to initialize it
    private static EventDBHelper helper;

    public static EventDBHelper getInstance(Context context) {
        if (helper == null) {
            helper = new EventDBHelper(context);
        }
        return helper;
    }

    private static final String DATABASE_NAME = "events.db";
    private static final int DATABASE_VERSION = 1;

    public EventDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private class EventsTable {
        private static final String TABLE = "events";

        private static final String COL_ID = "_id"; // primary key

        private static final String COL_NAME = "Name";

        private static final String COL_DATE = "Date";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + EventsTable.TABLE + " (" +
                EventsTable.COL_ID + " Integer primary key autoincrement, " +
                EventsTable.COL_NAME + " text, " +
                EventsTable.COL_DATE + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + EventsTable.TABLE);
        onCreate(db);
    }

    public void getAllEvents(@NonNull ArrayList<Event> events){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + EventsTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()) {
            do {

                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String date = cursor.getString(2);

                events.add(new Event(id, name, date));

            } while(cursor.moveToNext());
        }
        cursor.close();
    }

    public long add(Event event) {
        SQLiteDatabase db = getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(EventsTable.COL_NAME, event.getName());
        values.put(EventsTable.COL_DATE, event.getDate());

        long id = db.insert(EventsTable.TABLE, null,values);
        event.setId(id);

        return id;
    }

    public Boolean update(Event event) {
        SQLiteDatabase db = getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(EventsTable.COL_NAME, event.getName());
        values.put(EventsTable.COL_DATE, event.getDate());

        int rowsUpdated = db.update(EventsTable.TABLE, values, "_id = ?",
                new String [] { Long.toString(event.getId())}
        );
        return rowsUpdated > 0;
    }

    public Boolean delete(Event event) {
        SQLiteDatabase db = getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(EventsTable.COL_NAME, event.getName());
        values.put(EventsTable.COL_DATE, event.getDate());

        int rowsDeleted = db.delete(EventsTable.TABLE, EventsTable.COL_ID + "  = ?",
                new String [] { Long.toString(event.getId())}
        );

        return rowsDeleted > 0;
    }
}
